//VehicleUpdate.java
//Austin Trout

public class VehicleUpdate extends java.util.EventObject {
    public VehicleUpdate(Object source){
        super(source);
    }
}
